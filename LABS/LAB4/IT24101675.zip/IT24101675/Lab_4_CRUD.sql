USE StudentInformation;

-- Drop tables if they exist 
DROP TABLE IF EXISTS CourseModule;
DROP TABLE IF EXISTS Student;
DROP TABLE IF EXISTS Module;
DROP TABLE IF EXISTS Course;

-- Create Course table
CREATE TABLE Course (
    CID VARCHAR(10) PRIMARY KEY,
    Cname VARCHAR(100) NOT NULL,
    C_Description VARCHAR(500),
    C_fee DECIMAL(10,2)
);

-- Create Student table
CREATE TABLE Student (
    SID VARCHAR(15) PRIMARY KEY,
    Sname VARCHAR(100) NOT NULL,
    Address VARCHAR(200),
    Dob DATE,
    NIC VARCHAR(15),
    CID VARCHAR(10),
    FOREIGN KEY (CID) REFERENCES Course(CID)
);

-- Create Module table
CREATE TABLE Module (
    Mcode VARCHAR(10) PRIMARY KEY,
    Mname VARCHAR(100) NOT NULL,
    M_Description VARCHAR(500),
    NoOfCredits INT
);

-- Create CourseModule relationship table
CREATE TABLE CourseModule (
    CID VARCHAR(10),
    Mcode VARCHAR(10),
    Academic_year VARCHAR(10),
    Semester INT,
    PRIMARY KEY (CID, Mcode),
    FOREIGN KEY (CID) REFERENCES Course(CID),
    FOREIGN KEY (Mcode) REFERENCES Module(Mcode)
);

-- PART 1: INSERT DATA INTO TABLES

-- 1. Insert data into Course table
INSERT INTO Course (CID, Cname, C_Description, C_fee) VALUES
('IT', 'Information Technology', 'The programme is designed for technically focused students who capabilities in programming', 175000),
('SE', 'Software Engineering', 'Software engineering is the discipline of designing, creating and maintaining', 185000),
('CSNE', 'Computer Systems And Network Engineering', 'The programme aims to provide students with the knowledge, skills, planning, and designing', 155000),
('DS', 'Data Science', 'The meticulous curriculum focuses on the fundamentals of computer science, statistics, and applied mathematics', 170000);

-- 2. Insert data into Student table
INSERT INTO Student (SID, Sname, Address, Dob, NIC, CID) VALUES
('CN18384756', 'Kamal', 'No122, Rose street, matale', '1994-05-02', '946785467v', 'CSNE'),
('DS18234876', 'Pubudu', 'No678 , 3rd new lane, Maharahgama', '1994-11-08', '948763759v', 'DS'),
('IT18234568', 'Ann', 'No12, Kings street, colombo', '1996-11-11', '961234587v', 'IT'),
('SE19238567', 'Malith', 'No08, st.thomas street, Kandy', '1992-12-20', '922356785v', 'SE');

-- 3. Insert data into Module table
INSERT INTO Module (Mcode, Mname, M_Description, NoOfCredits) VALUES
('SE3050', 'User Experience Engineering', 'subject under SE', 3),
('IT1010', 'Introduction to Programming', 'subject under IT', 4),
('IT2050', 'Computer Networks', 'subject under IT', 4),
('IT3051', 'Fundamentals of Data Mining', 'subject under DS', 4);

-- 4. Insert data into CourseModule table
INSERT INTO CourseModule (CID, Mcode, Academic_year, Semester) VALUES
('SE', 'SE3050', 'Y3', 2),
('IT', 'IT1010', 'Y1', 2),
('IT', 'IT2050', 'Y2', 1),
('DS', 'IT3051', 'Y3', 2);

-- Verify the data insertion
SELECT 'Course Table' as TableName;
SELECT * FROM Course;

SELECT 'Student Table' as TableName;
SELECT * FROM Student;

SELECT 'Module Table' as TableName;
SELECT * FROM Module;

SELECT 'CourseModule Table' as TableName;
SELECT * FROM CourseModule;

-- PART 2: 
-- Update the address of student named Ann
UPDATE Student 
SET Address = 'No15, New Kings street, colombo' 
WHERE Sname = 'Ann';

-- Verify the update
SELECT 'Updated Student Ann' as Operation;
SELECT * FROM Student WHERE Sname = 'Ann';

-- PART 3: DELETE DATA
-- Remove the module 'User Experience Engineering' from the Module table
DELETE FROM CourseModule WHERE Mcode = 'SE3050';

-- Then delete from Module table
DELETE FROM Module WHERE Mname = 'User Experience Engineering';

-- Verify the deletion
SELECT 'Remaining Modules after deletion' as Operation;
SELECT * FROM Module;

SELECT 'Remaining CourseModule records after deletion' as Operation;
SELECT * FROM CourseModule;
