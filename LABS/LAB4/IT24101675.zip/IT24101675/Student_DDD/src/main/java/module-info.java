module com.example.student_ddd {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens com.example.student_ddd to javafx.fxml;
    exports com.example.student_ddd;
}