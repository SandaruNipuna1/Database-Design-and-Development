package com.example.student_ddd;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.*;
import java.time.LocalDate;

public class StudentController {

    @FXML private TextField sidField;
    @FXML private TextField nameField;
    @FXML private TextField addressField;
    @FXML private DatePicker dobPicker;
    @FXML private TextField nicField;
    @FXML private ComboBox<String> courseComboBox;
    @FXML private TextArea resultArea;

    @FXML
    public void initialize() {
        loadCourses();
    }

    private void loadCourses() {
        String sql = "SELECT CID, Cname FROM Course";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            courseComboBox.getItems().clear();
            while (rs.next()) {
                String courseItem = rs.getString("CID") + " - " + rs.getString("Cname");
                courseComboBox.getItems().add(courseItem);
            }

        } catch (SQLException e) {
            resultArea.setText("Error loading courses: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void insertStudent() {
        String sql = "INSERT INTO Student (SID, Sname, Address, Dob, NIC, CID) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Validate input fields
            if (sidField.getText().trim().isEmpty() || nameField.getText().trim().isEmpty()) {
                resultArea.setText("Student ID and Name are required!");
                return;
            }

            if (courseComboBox.getValue() == null) {
                resultArea.setText("Please select a course!");
                return;
            }

            // Extract CID from combo box selection
            String selectedCourse = courseComboBox.getValue();
            String cid = selectedCourse.split(" - ")[0];

            // Set parameters
            pstmt.setString(1, sidField.getText().trim());
            pstmt.setString(2, nameField.getText().trim());
            pstmt.setString(3, addressField.getText().trim());

            if (dobPicker.getValue() != null) {
                pstmt.setDate(4, Date.valueOf(dobPicker.getValue()));
            } else {
                pstmt.setNull(4, Types.DATE);
            }

            pstmt.setString(5, nicField.getText().trim());
            pstmt.setString(6, cid);

            // Execute insert
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                resultArea.setText("Student inserted successfully!");
                clearFields();
            } else {
                resultArea.setText("Failed to insert student.");
            }

        } catch (SQLException e) {
            if (e.getMessage().contains("PRIMARY KEY constraint")) {
                resultArea.setText("Error: Student ID already exists!");
            } else if (e.getMessage().contains("FOREIGN KEY constraint")) {
                resultArea.setText("Error: Invalid course selection!");
            } else {
                resultArea.setText("Database error: " + e.getMessage());
            }
            e.printStackTrace();
        }
    }

    @FXML
    public void updateStudent() {
        String sql = "UPDATE Student SET Sname = ?, Address = ?, Dob = ?, NIC = ?, CID = ? WHERE SID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Validate input fields
            if (sidField.getText().trim().isEmpty()) {
                resultArea.setText("Please enter a Student ID to update.");
                return;
            }

            if (nameField.getText().trim().isEmpty()) {
                resultArea.setText("Student Name is required!");
                return;
            }

            if (courseComboBox.getValue() == null) {
                resultArea.setText("Please select a course!");
                return;
            }

            // Extract CID from combo box selection
            String selectedCourse = courseComboBox.getValue();
            String cid = selectedCourse.split(" - ")[0];

            // Set parameters
            pstmt.setString(1, nameField.getText().trim());
            pstmt.setString(2, addressField.getText().trim());

            if (dobPicker.getValue() != null) {
                pstmt.setDate(3, Date.valueOf(dobPicker.getValue()));
            } else {
                pstmt.setNull(3, Types.DATE);
            }

            pstmt.setString(4, nicField.getText().trim());
            pstmt.setString(5, cid);
            pstmt.setString(6, sidField.getText().trim());

            // Execute update
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                resultArea.setText("Student updated successfully!");
            } else {
                resultArea.setText("No student found with the given ID.");
            }

        } catch (SQLException e) {
            resultArea.setText("Database error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void deleteStudent() {
        String sql = "DELETE FROM Student WHERE SID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Validate input field
            if (sidField.getText().trim().isEmpty()) {
                resultArea.setText("Please enter a Student ID to delete.");
                return;
            }

            pstmt.setString(1, sidField.getText().trim());

            // Execute delete
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                resultArea.setText("Student deleted successfully!");
                clearFields();
            } else {
                resultArea.setText("No student found with the given ID.");
            }

        } catch (SQLException e) {
            resultArea.setText("Database error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void loadStudent() {
        String sql = "SELECT s.*, c.Cname FROM Student s LEFT JOIN Course c ON s.CID = c.CID WHERE s.SID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Validate input field
            if (sidField.getText().trim().isEmpty()) {
                resultArea.setText("Please enter a Student ID to load.");
                return;
            }

            pstmt.setString(1, sidField.getText().trim());
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                nameField.setText(rs.getString("Sname"));
                addressField.setText(rs.getString("Address"));

                Date dob = rs.getDate("Dob");
                if (dob != null) {
                    dobPicker.setValue(dob.toLocalDate());
                } else {
                    dobPicker.setValue(null);
                }

                nicField.setText(rs.getString("NIC"));

                // Set course combo box
                String cid = rs.getString("CID");
                String courseName = rs.getString("Cname");
                if (cid != null && courseName != null) {
                    String courseItem = cid + " - " + courseName;
                    courseComboBox.setValue(courseItem);
                }

                resultArea.setText("Student loaded successfully!");
            } else {
                resultArea.setText("No student found with the given ID.");
                clearDataFields();
            }

        } catch (SQLException e) {
            resultArea.setText("Database error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void clearFields() {
        sidField.clear();
        clearDataFields();
        resultArea.clear();
    }

    private void clearDataFields() {
        nameField.clear();
        addressField.clear();
        dobPicker.setValue(null);
        nicField.clear();
        courseComboBox.setValue(null);
    }

    @FXML
    public void showAllStudents() {
        String sql = "SELECT s.SID, s.Sname, s.Address, s.Dob, s.NIC, c.Cname FROM Student s LEFT JOIN Course c ON s.CID = c.CID ORDER BY s.SID";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            StringBuilder result = new StringBuilder();
            result.append("All Students:\n");
            result.append("====================\n");

            while (rs.next()) {
                result.append("ID: ").append(rs.getString("SID")).append("\n");
                result.append("Name: ").append(rs.getString("Sname")).append("\n");
                result.append("Address: ").append(rs.getString("Address")).append("\n");
                result.append("DOB: ").append(rs.getDate("Dob")).append("\n");
                result.append("NIC: ").append(rs.getString("NIC")).append("\n");
                result.append("Course: ").append(rs.getString("Cname")).append("\n");
                result.append("--------------------\n");
            }

            resultArea.setText(result.toString());

        } catch (SQLException e) {
            resultArea.setText("Database error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}