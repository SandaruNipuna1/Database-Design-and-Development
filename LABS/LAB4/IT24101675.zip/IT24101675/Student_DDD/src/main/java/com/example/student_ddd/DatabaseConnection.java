package com.example.student_ddd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // Option 1: SQL Server Authentication (sa user)
    private static final String URL_SA = "jdbc:sqlserver://localhost:1433;databaseName=StudentInformation;encrypt=false;trustServerCertificate=true;";
    private static final String USERNAME_SA = "sa";
    private static final String PASSWORD_SA = "ddd1228";
    
    // Option 2: Windows Authentication (Integrated Security)
    private static final String URL_WINDOWS = "jdbc:sqlserver://localhost:1433;databaseName=StudentInformation;encrypt=false;trustServerCertificate=true;integratedSecurity=true;";
    
    // Option 3: Connection without specific database (for initial setup)
    private static final String URL_MASTER = "jdbc:sqlserver://localhost:1433;encrypt=false;trustServerCertificate=true;";

    public static Connection getConnection() throws SQLException {
        return getConnectionWithFallback();
    }
    
    public static Connection getConnectionToMaster() throws SQLException {
        return getConnectionWithFallback(URL_MASTER);
    }
    
    private static Connection getConnectionWithFallback() throws SQLException {
        return getConnectionWithFallback(URL_SA);
    }
    
    private static Connection getConnectionWithFallback(String url) throws SQLException {
        // Try SQL Server Authentication first
        try {
            System.out.println("Attempting SQL Server Authentication...");
            return DriverManager.getConnection(url, USERNAME_SA, PASSWORD_SA);
        } catch (SQLException e) {
            System.err.println("SQL Server Authentication failed: " + e.getMessage());
            
            // Try Windows Authentication
            try {
                System.out.println("Attempting Windows Authentication...");
                return DriverManager.getConnection(URL_WINDOWS);
            } catch (SQLException e2) {
                System.err.println("Windows Authentication failed: " + e2.getMessage());
                throw new SQLException("Both SQL Server and Windows Authentication failed. Please check your SQL Server configuration.", e2);
            }
        }
    }
    
    public static void testConnection() {
        try (Connection connection = getConnection()) {
            System.out.println("Database connection successful!");
            System.out.println("Connected to: " + connection.getMetaData().getDatabaseProductName());
            System.out.println("Database: " + connection.getCatalog());
        } catch (SQLException e) {
            System.err.println("Connection test failed: " + e.getMessage());
            System.err.println("Error Code: " + e.getErrorCode());
            System.err.println("SQL State: " + e.getSQLState());
            
            // Provide troubleshooting tips
            System.err.println("\nTroubleshooting Tips:");
            System.err.println("1. Make sure SQL Server is running");
            System.err.println("2. Verify SQL Server is configured for mixed mode authentication");
            System.err.println("3. Check if 'sa' account is enabled and password is correct");
            System.err.println("4. Ensure SQL Server Browser service is running");
            System.err.println("5. Check firewall settings for port 1433");
            System.err.println("6. Try using Windows Authentication instead");
        }
    }
    
    public static void main(String[] args) {
        testConnection();
    }
}
