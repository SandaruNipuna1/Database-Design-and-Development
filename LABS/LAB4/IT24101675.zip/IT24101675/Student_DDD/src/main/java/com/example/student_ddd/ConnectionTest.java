package com.example.student_ddd;

public class ConnectionTest {
    
    public static void main(String[] args) {
        System.out.println("=== SQL Server Connection Test ===\n");
        
        // Test the connection
        DatabaseConnection.testConnection();
        
        System.out.println("\n=== Connection Test Complete ===");
    }
}
