package com.example.student_ddd;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseSetup {
    
    public static void setupDatabase() {
        // First test the connection
        System.out.println("Testing database connection...");
        DatabaseConnection.testConnection();
        
        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement()) {
            
            System.out.println("\nStarting database setup...");
            
            // Read and execute the SQL script
            String sqlScript = readSqlScript();
            
            // Split by GO statements for SQL Server
            String[] batches = sqlScript.split("(?i)\\bGO\\b");
            
            for (int i = 0; i < batches.length; i++) {
                String batch = batches[i].trim();
                if (!batch.isEmpty()) {
                    // Split each batch by semicolons
                    String[] commands = batch.split(";");
                    
                    for (String command : commands) {
                        command = command.trim();
                        if (!command.isEmpty() && !command.startsWith("--")) {
                            try {
                                statement.execute(command);
                                System.out.println("✓ Executed: " + command.substring(0, Math.min(50, command.length())) + "...");
                            } catch (SQLException e) {
                                System.err.println("✗ Error executing: " + command);
                                System.err.println("  Error: " + e.getMessage());
                                // Continue with other commands instead of stopping
                            }
                        }
                    }
                }
            }
            
            System.out.println("\nDatabase setup completed!");
            
        } catch (SQLException | IOException e) {
            System.err.println("Error setting up database: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public static void createDatabaseOnly() {
        try (Connection connection = DatabaseConnection.getConnectionToMaster();
             Statement statement = connection.createStatement()) {
            
            System.out.println("Creating StudentInformation database...");
            
            // Create database if it doesn't exist
            String createDbSQL = 
                "IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'StudentInformation') " +
                "BEGIN " +
                "    CREATE DATABASE StudentInformation; " +
                "END";
            
            statement.execute(createDbSQL);
            System.out.println("✓ Database 'StudentInformation' created successfully!");
            
        } catch (SQLException e) {
            System.err.println("Error creating database: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static String readSqlScript() throws IOException {
        StringBuilder script = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader("database_setup.sql"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                script.append(line).append("\n");
            }
        }
        return script.toString();
    }
    
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("--create-db-only")) {
            createDatabaseOnly();
        } else {
            setupDatabase();
        }
    }
}
